module.exports = require('./colorbrewer.js');
